<?php

namespace Renascer\Events;

abstract class Event
{
    //
}
