<!DOCTYPE html>
<html>
<head>
	<title></title>
	<script type="text/javascript">

	function paginaPrincipal() {
		location.href="public/";			
	}
	</script>
</head>
<body onload="paginaPrincipal();">

</body>
</html>